@extends('layouts.admin')
@section('content')

<div>
    <livewire:admin.category.index>
</div>


@endsection