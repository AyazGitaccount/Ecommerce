@extends('layouts.admin')
{{-- @section('title1','site settings') --}}
@section('content')

<div>
    <livewire:admin.site-setting.site-setting>
</div>


@endsection