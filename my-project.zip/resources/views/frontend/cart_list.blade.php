@extends('layouts.app')
@section('title','Cart List')

<div>
    <livewire:frontend.cartlist>
</div>

@endsection