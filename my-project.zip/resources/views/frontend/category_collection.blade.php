@extends('layouts.app')
@section('title','All Categories')

<div>
    <livewire:frontend.category-collection>
</div>

@endsection