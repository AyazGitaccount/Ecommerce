@extends('layouts.app')
@section('title','change password')

<div>
    <livewire:change-password.change-password>
</div>

@endsection