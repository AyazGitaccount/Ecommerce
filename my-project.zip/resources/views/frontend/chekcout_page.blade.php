@extends('layouts.app')
@section('title','Checkout')

<div>
    <livewire:frontend.checkout.checkout>
</div>

@endsection