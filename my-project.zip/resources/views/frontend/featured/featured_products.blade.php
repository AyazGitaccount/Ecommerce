@extends('layouts.app')
@section('title','Cart List')

<div>
    <livewire:frontend.featured.featured-products>
</div>

@endsection