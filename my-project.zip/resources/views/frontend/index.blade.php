@extends('layouts.app')
@section('title','Home Slider')
<div>
    <livewire:frontend.front-index>
</div>
@endsection
