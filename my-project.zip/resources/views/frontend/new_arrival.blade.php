@extends('layouts.app')
@section('title','New Arrival')

<div>
    <livewire:frontend.new-arrival.new-arrival-products>
</div>

@endsection