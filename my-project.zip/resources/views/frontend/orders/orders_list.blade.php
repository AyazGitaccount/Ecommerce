@extends('layouts.app')
@section('title','Orders')
<div>
    <livewire:frontend.orders.orders-list>
</div>
@endsection