@extends('layouts.app')
@section('title','Profile')

<div>
    <livewire:user-profile.user-profile >
</div>

@endsection