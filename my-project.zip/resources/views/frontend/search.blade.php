@extends('layouts.app')

<div>
    <livewire:frontend.search.search-products>
</div>