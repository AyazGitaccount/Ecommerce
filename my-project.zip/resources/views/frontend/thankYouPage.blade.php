@extends('layouts.app')
@section('title','Thank You')

<div>
    <livewire:frontend.thank-you-page>
</div>

@endsection