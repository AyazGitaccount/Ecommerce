@extends('layouts.app')
@section('title','product')

<div>
    <livewire:frontend.view-product>
</div>


@endsection
