@extends('layouts.app')
@section('title','Wishlist')
<div>
    <livewire:frontend.wishlist-page>
</div>
@endsection