<div class="d-inline">
{{ $Cart_count }}
</div>
