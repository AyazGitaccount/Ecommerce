
<?php $__env->startSection('title','Products'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.products', ['products' => $products])->html();
} elseif ($_instance->childHasBeenRendered('d8CKi4H')) {
    $componentId = $_instance->getRenderedChildComponentId('d8CKi4H');
    $componentTag = $_instance->getRenderedChildComponentTagName('d8CKi4H');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d8CKi4H');
} else {
    $response = \Livewire\Livewire::mount('frontend.products', ['products' => $products]);
    $html = $response->html();
    $_instance->logRenderedChild('d8CKi4H', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/frontend/products.blade.php ENDPATH**/ ?>