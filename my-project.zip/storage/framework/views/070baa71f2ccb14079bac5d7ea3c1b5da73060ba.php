<div class="py-5 bg-white">
    <div class="container">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="mb-4">Search Result</h4>
                <div class="underline"></div>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $search_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3">
                <div class="product-card shadow">
                    <div class="product-card-img">
                        <label class="stock bg-danger">New</label>
                        <?php if($item->productImages->count()>0): ?>
                        <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                            <img src="<?php echo e(asset($item->productImages[0]->image)); ?>" class="w-100" style="height:155px"
                                alt="<?php echo e($item->name); ?>">
                        </a>
                        <?php endif; ?>

                    </div>
                    <div class="product-card-body">
                        <p class="product-brand"><?php echo e($item->brand); ?></p>
                        <h5 class="product-name">
                            <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                                <?php echo e($item->name); ?>

                            </a>
                        </h5>
                        <div>
                            <span class="selling-price"><?php echo e($item->selling_price); ?></span>
                            <span class="original-price"><?php echo e($item->selling_price); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12 p-2">
                <h4>No Product Avilable</h4>
            </div>
            <?php endif; ?>

        </div>
        <div>
            <?php echo e($search_result->links()); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/search/search-products.blade.php ENDPATH**/ ?>