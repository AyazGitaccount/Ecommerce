
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>
                        Colors List
                        <a href="<?php echo e(url('admin/colors/create')); ?>" class="btn btn-primary btn-sm float-end">Add
                            Add colors</a>
                    </h4>
                </div>
            </div>
            <div class="card-body" style="background-color: white;">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Color Name</th>
                            <th scope="col">Color Code</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($color->id); ?></th>
                            <td><?php echo e($color->name); ?></td>
                            <td><?php echo e($color->code); ?></td>
                            <td><?php echo e($color->status == '1' ? 'Hidden':'Visible'); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/colors/'.$color->id.'/edit')); ?>" class="btn btn-success me-2">Edit</a>
                                <a href="<?php echo e(url('admin/colors/'.$color->id.'/delete')); ?>" onclick="return confirm('Are your sure you want to delete this data ?') " class="btn btn-danger" >Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/colors/index.blade.php ENDPATH**/ ?>