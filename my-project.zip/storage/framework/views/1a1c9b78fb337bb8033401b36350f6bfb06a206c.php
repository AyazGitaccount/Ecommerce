<div>
    <form wire:submit.prevent='register' role="search">
        <div class="input-group">
            <input type="search" wire:model="search" value="" placeholder="Search your product" class="form-control" />
            <a href="<?php echo e(url('/search')); ?>" class="btn bg-white" type="submit">
                <i class="fa fa-search"></i>
            </a>
        </div>
    </form>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/search.blade.php ENDPATH**/ ?>