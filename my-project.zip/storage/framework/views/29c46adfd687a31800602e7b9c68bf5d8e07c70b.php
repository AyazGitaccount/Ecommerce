<div class="d-inline">
 <?php echo e($wishlistCount); ?>

</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/wishlist-count.blade.php ENDPATH**/ ?>