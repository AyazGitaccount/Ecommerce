<div class="py-3 py-md-5 bg-light">
    <div class="container">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-5 mt-3">
                <div class="bg-white border" wire:ignore>
                    <?php if($product->productImages->count()>0): ?>
                    <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" style="height:350px" class="w-100"
                        alt="Img">
                        
                    <?php else: ?>
                     No image addes
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-7 mt-3">
                <div class="product-view">
                    <h4 class="product-name">
                        <?php echo e($product->name); ?>

                    </h4>
                    <hr>
                    <p class="product-path">
                        Home / <?php echo e($product->category->name); ?> /<?php echo e($product->name); ?>

                    </p>
                    <div>
                        <span class="selling-price">$<?php echo e($product->selling_price); ?></span>
                        <span class="original-price">$<?php echo e($product->original_price); ?></span>
                    </div>
                    <div class="mt-2 mb-2">
                    </div>
                    <div>
                        <?php if($product->productColors->count()>0 && $product->quantity >0): ?>
                            <?php if($product->productColors): ?>
                                <?php $__currentLoopData = $product->productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <label class="colorSelectionLabel" style="background-color:<?php echo e($color_item->color->code); ?>" wire:click='colorSelected(<?php echo e($color_item->id); ?>)'>
                                    <?php echo e($color_item->color->name); ?>

                                </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                           
                            <?php if($this->prod_color_selected_quantity=='outOfStock'): ?>
                            <label class="btn-sm  text-white btn btn-danger">Out of Stock</label>                                
                            
                            <?php elseif($this->prod_color_selected_quantity> 0): ?>
                            <label class="text-white btn btn-success btn-sm">In Stock</label>
                            <?php endif; ?>
                         
                        <?php else: ?> 
                            <?php if($product->quantity >0): ?>
                            <label class="text-white btn btn-success btn-sm">In Stock</label>
                            <?php else: ?>
                            <label class="btn-sm  text-white btn btn-danger">Out of Stock</label>
                            <?php endif; ?>   
                        <?php endif; ?>
                        
                    </div>
                    <?php if($product->quantity >0): ?>
                    
                    <div class="mt-2">
                        <div class="input-group">
                            <span class="btn btn1" wire:click='decrementQuantity'><i class="fa fa-minus"></i></span>
                            <input type="text" wire:model='quantityCount' value="<?php echo e($this->quantityCount); ?>" readonly class="input-quantity" />
                            <span class="btn btn1" wire:click='incrementQuantity'><i class="fa fa-plus"></i></span>
                        </div>
                    </div>
                   
                        <div class="mt-2">
                            <button type="button" wire:click='addToCart(<?php echo e($product->id); ?>)' class="btn btn1">
                                <span  wire:loading.remove wire:target='addToCart'>
                                    <i class="fa fa-shopping-cart"></i> Add To Cart                            
                                </span>
                                <span wire:loading wire:target='addToCart'>Adding... </span>
                            </button>
                            
                            <button type="button" wire:click='addToWhishlist(<?php echo e($product->id); ?>)' class="btn btn1">  
                                <span wire:loading.remove wire:target='addToWhishlist'>
                                    <i class="fa fa-heart"></i> Add To Wishlist
                                </span>
                                <span wire:loading wire:target='addToWhishlist'>Adding... </span>
                        </button>
                       </div>
                    
                    <?php endif; ?>
                    <div class="mt-3">
                        <h5 class="mb-0">Small Description</h5>
                        <p>
                            <?php echo $product->small_description; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 mt-3">
                <div class="card">
                    <div class="card-header bg-white">
                        <h4>Description</h4>
                    </div>
                    <div class="card-body">
                        <p>
                            <?php echo e($product->description); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="py-3 py-md-5 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <h3>Related Products</h3>
                    <div class="underline"></div>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $category->related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-3">
                        <div class="product-card shadow">
                            <div class="product-card-img">
                                <?php if($item->productImages->count()>0): ?>
                                <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                                    <img src="<?php echo e(asset($item->productImages[0]->image)); ?>" class="w-100" style="height:155px"
                                        alt="<?php echo e($item->name); ?>">
                                </a>
                                <?php endif; ?>

                            </div>
                            <div class="product-card-body">
                                <p class="product-brand"><?php echo e($item->brand); ?></p>
                                <h5 class="product-name">
                                    <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                                        <?php echo e($item->name); ?>

                                    </a>
                                </h5>
                                <div>
                                    <span class="selling-price"><?php echo e($item->selling_price); ?></span>
                                    <span class="original-price"><?php echo e($item->selling_price); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 p-2">
                        <h4>No Product Avilable</h4>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/view-product.blade.php ENDPATH**/ ?>