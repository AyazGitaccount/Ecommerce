
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>
                        Orders                        
                    </h4>
                </div>
            </div>
            <div class="card-body" style="background-color: white;">
                
                <form action="" method="GET">
                    <div class="row">
                        <div class="col-md-3 mb-2">
                            <label for="">Filter by Date</label>
                            <input type="date" name="date" value="<?php echo e(Request::get('date') ?? date('Y-m-d')); ?>" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label for="">Filter by Status</label>
                           <select name="status" class="form-select">
                            <option value="">Select All Status</option>
                            <option value="in progress" <?php echo e(Request::get('status')=='in progress' ? 'selected':''); ?>>In progress</option>
                            <option value="completed" <?php echo e(Request::get('status')=='completed' ? 'selected':''); ?>>Completed</option>
                            <option value="pending"<?php echo e(Request::get('status')=='pending' ? 'selected':''); ?>>Pending</option>
                            <option value="cancelled"<?php echo e(Request::get('status')=='cancelled' ? 'selected':''); ?>>Cancelled</option>
                            <option value="out-for-delivery"<?php echo e(Request::get('status')=='out-for-delivery' ? 'selected':''); ?>>Out for delivery</option>
                           </select>
                        </div>
                        <div class="col-md-6">
                            <br>
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </div>
                </form>
               <hr>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <th>Order ID</th>
                            <th>Tracking no.</th>
                            <th>Username</th>
                            <th>Payment Mode</th>
                            <th>Ordered Date</th>
                            <th>Status Message</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->tracking_no); ?></td>
                                <td><?php echo e($order->fullname); ?></td>
                                <td><?php echo e($order->payment_mode); ?></td>
                                <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($order->status_message); ?></td>
                                <td><a href="<?php echo e(url('/admin/orders/'.$order->id)); ?>"
                                        class="btn btn-primary btn-sm ms-3">View</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr colspan="7">
                                No Orders available
                            </tr>
                            <?php endif; ?>


                        </tbody>
                    </table>
                    <div>
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/orders/display_order_list.blade.php ENDPATH**/ ?>