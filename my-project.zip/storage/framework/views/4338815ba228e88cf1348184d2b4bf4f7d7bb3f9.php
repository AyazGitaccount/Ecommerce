
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>
                        Slider List
                        <a href="<?php echo e(url('admin/slider/create')); ?>" class="btn btn-primary btn-sm float-end">Add
                            Slider</a>
                    </h4>
                </div>

                <div class="card-body" style="background-color: white;">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Title</th>
                                <th scope="col">Description</th>
                                <th scope="col">Image</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($slider->id); ?></td>
                                <td>
                                    <?php echo e($slider->title); ?>

                                </td>
                                <td><?php echo e($slider->description); ?></td>
                                <td> <img src="<?php echo e(asset("$slider->image")); ?>" alt="slider" style="width:70px;
                                    height:70px;"></td>
                                <td><?php echo e($slider->status == '1' ? 'Hidden':'Visible'); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/slider/'.$slider->id.'/edit')); ?>"
                                        class="btn btn-success me-2 btn-sm">Edit</a>
                                    
                                    <a href="<?php echo e(url('admin/slider/'.$slider->id.'/delete')); ?>"
                                        onclick="return confirm('Are your sure you want to delete this data ?')"
                                        class="btn btn-sm btn-danger m-2">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">No Products Available</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>