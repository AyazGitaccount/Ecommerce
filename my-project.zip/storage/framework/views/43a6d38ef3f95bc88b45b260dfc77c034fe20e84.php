
<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.category.index', [])->html();
} elseif ($_instance->childHasBeenRendered('qu4Hy3w')) {
    $componentId = $_instance->getRenderedChildComponentId('qu4Hy3w');
    $componentTag = $_instance->getRenderedChildComponentTagName('qu4Hy3w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qu4Hy3w');
} else {
    $response = \Livewire\Livewire::mount('admin.category.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('qu4Hy3w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/category/index.blade.php ENDPATH**/ ?>