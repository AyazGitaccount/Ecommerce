<div>
    <?php echo $__env->make('livewire.admin.brand.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Brand List
                            <a href="<?php echo e(route('create')); ?>" class="btn btn-primary btn-sm float-end"  data-bs-toggle="modal" data-bs-target="#addbrandModal">Add Brand</a>
                        </h4>
                    </div>
                    <div class="card-boady m-3">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Slug</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                    <?php if($item->category): ?>
                                    <?php echo e($item->category->name); ?>

                                     <?php else: ?>
                                     No Category avilable
                                     <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->slug); ?></td>
                                    <td><?php echo e($item->status == '1' ? 'Hidden':'Visible'); ?></td>
                                    <td>
                                        <a href="#" wire:click='edit_Brand(<?php echo e($item->id); ?>)'  data-bs-toggle="modal" data-bs-target="#UpdateBrandModal"  class="btn btn-success me-2">Edit</a>
                                        <a  wire:click='delete_brand(<?php echo e($item->id); ?>)' class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#destoryBrandModal">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-2">
                            <?php echo e($brand->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/admin/brand/index.blade.php ENDPATH**/ ?>