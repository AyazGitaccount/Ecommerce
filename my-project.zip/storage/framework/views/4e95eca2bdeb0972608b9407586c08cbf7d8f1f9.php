<div class="py-3 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="shadow bg-white p-3">
                    <h4 class="text-primary">
                        <i class="fa fa-shopping-cart text-dark"></i> My Order Details
                        <a href="<?php echo e(url('/orders')); ?>" class="btn btn-danger btn-sm float-end">Back</a>
                    </h4>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Order Details</h5>
                            <hr>
                            <h6>Order ID: <?php echo e($order->id); ?></h6>
                            <h6>Tracking Id/No.:<?php echo e($order->tracking_id); ?></h6>
                            <h6>Order Created: <?php echo e($order->created_at->format('d-m-Y h:i A')); ?> </h6>
                            <h6>Payment Mode: <?php echo e($order->payment_mode); ?></h6>
                            <h6 class="border p-2 text-success">Order Status Message: <span class="text-uppercase"><?php echo e($order->status_message); ?></span> </h6>
                        </div>
                        <div class="col-md-6">
                            <h5>User Details</h5>
                            <hr>
                            <h6>Full Name: <?php echo e($order->fullname); ?> </h6>
                            <h6>Email: <?php echo e($order->email); ?></h6>
                            <h6>Phone:<?php echo e($order->phone); ?> </h6>
                            <h6>Address: <?php echo e($order->address); ?></h6>
                            <h6>Pin code: <?php echo e($order->pincode); ?> </h6>
                        </div>
                    </div>
                    <br>
                    <h5>Order Items</h5>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>Item ID</th>
                                <th>Image</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </thead>
                            <tbody>
                                <?php
                                    $total_Price =0;
                                ?>
                                <?php $__currentLoopData = $order->order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="10%"><?php echo e($items->id); ?></td>
                                    <td width="10%">
                                        <?php if($items->product->productImages): ?>
                                        <img src="<?php echo e(asset($items->product->productImages[0]->image)); ?>"
                                            style="width: 50px; height: 50px" alt="">
                                        <?php endif; ?>
                                       
                                    </td>
                                    <td>
                                        <?php echo e($items->product->name); ?>

                                        <?php if($items->productColor): ?>
                                        <?php if($items->productColor->color): ?>
                                        <span>- Color : <?php echo e($items->productColor->color->name); ?></span>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td width="10%">$<?php echo e($items->price); ?></td>
                                    <td width="10%"><?php echo e($items->quantity); ?></td>
                                    <td width="10%" class="fw-bold">$<?php echo e($items->quantity * $items->price); ?></td>
                                    <?php
                                        $total_Price += $items->quantity * $items->price ;
                                    ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td colspan="5" class="fw-bold">Total Price</td>
                                <td colspan="1" class="fw-bold">$<?php echo e($total_Price); ?></td>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/orders/view-order.blade.php ENDPATH**/ ?>