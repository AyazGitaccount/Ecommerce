<div class="container " style="min-height: 100vh;">
    <div>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row justify-content-center my-5">
        <div class="col-md-6">
            <div class="card py-4 px-5 shadow" style="background-color:rgb(247, 247, 247);">
                <div class="card-body ">
                    <div class="d-flex justify-content-center">
                        <h2>LOG IN</h2>
                    </div>
                    <form class="pt-3" wire:submit.prevent="login">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" class="form-control" wire:model="email" id="exampleInputEmail1"
                                aria-describedby="emailHelp">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" class="form-control" wire:model="password" id="exampleInputPassword1">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <button type="submit" class="btn btn-primary mt-2 form-control">Login</button>
                        
                    </form>
                    <p class="text-lead text-center mt-4">Don't have an account ? <a href="<?php echo e(url('/register')); ?>" class="text-decoration-none"> Register</a></p>
                    <div class="text-center">
                        <i class="fa-brands fa-facebook me-2"></i>                                   
                        
                        <i class="fa-brands fa-github me-2"></i>                                   
                        <a href="<?php echo e(url('authorized/google')); ?>" class="text-decoration-none" style="color:black">
                            <i class="fa-brands fa-google me-2">      </i>                                   
                        </a>
                        
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/login.blade.php ENDPATH**/ ?>