<div class="py-3 py-md-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php if($category->brands): ?>
                <div class="card shadow">
                    <div class="card-header">
                        <H4>Brands</H4>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $category->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <label class="d-block">
                            <input type="checkbox" wire:model='brandInputs' value="<?php echo e($item->name); ?>"> <?php echo e($item->name); ?>

                        </label>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                    </div>
                </div>
                <?php endif; ?>
                <div class="card mt-3 shadow">
                    <div class="card-header">
                        <H4>Price</H4>
                    </div>
                    <div class="card-body">
                         <label class="d-block">
                            <input type="radio" name="piceSort"  wire:model='priceInput' value="high-to-low"> High to Low
                        </label> 
                        <label class="d-block">
                            <input type="radio" name="piceSort" wire:model='priceInput' value="low-to-high">Low To High
                        </label>            
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="mb-4">Our Products</h4>
                    </div>
                   
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="product-card shadow">
                            <div class="product-card-img">
                                <?php if($item->quantity > 0): ?>
                                <label class="stock bg-success">In Stock</label>
                                <?php else: ?>
                                <label class="stock bg-danger">Out of Stock</label>
                                <?php endif; ?>

                                <?php if($item->productImages->count()>0): ?>
                                <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                                    <img src="<?php echo e(asset($item->productImages[0]->image)); ?>" class="w-100" style="height:155px" alt="<?php echo e($item->name); ?>">
                                </a>
                                <?php endif; ?>
                                
                            </div>
                            <div class="product-card-body">
                                <p class="product-brand"><?php echo e($item->brand); ?></p>
                                <h5 class="product-name">
                                    <a href="<?php echo e(url('/collections/'.$item->category->slug.'/'.$item->slug)); ?>">
                                        <?php echo e($item->name); ?>

                                    </a>
                                </h5>
                                <div>
                                    <span class="selling-price"><?php echo e($item->selling_price); ?></span>
                                    <span class="original-price"><?php echo e($item->selling_price); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <h4 class="mb-4">No Product Avilable for <?php echo e($category->name); ?></h4>
                    </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/products.blade.php ENDPATH**/ ?>