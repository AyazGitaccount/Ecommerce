
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4>
                    Edit Product
                    <a href="<?php echo e(url('admin/products')); ?>" class="btn btn-primary btn-sm float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-warning">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(url('/admin/products/'.$product->id)); ?>" class="mx-3" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                                aria-selected="true">Home</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="seo-tab" data-bs-toggle="tab" data-bs-target="#seo-tab-pane"
                                type="button" role="tab" aria-controls="seo-tab-pane" aria-selected="false">SEO
                                Tags</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="details-tab" data-bs-toggle="tab"
                                data-bs-target="#details-tab-pane" type="button" role="tab"
                                aria-controls="details-tab-pane" aria-selected="false">Details</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="image-tab" data-bs-toggle="tab"
                                data-bs-target="#image-tab-pane" type="button" role="tab" aria-controls="image-tab-pane"
                                aria-selected="false">Product Images</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="image-tab" data-bs-toggle="tab"
                                data-bs-target="#color-tab-pane" type="button" role="tab" aria-controls="color-tab-pane"
                                aria-selected="false">Product Color</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel"
                            aria-labelledby="home-tab" tabindex="0">
                            <div class="my-3">
                                <label class="form-label"> Category</label>
                                <select name="category_id" class="form-control">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ?
                                        'selected':''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"> Product name</label>
                                <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label"> Product slug</label>
                                <input type="text" name="slug" value="<?php echo e($product->slug); ?>" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label"> Select Brand</label>
                                <select name="brand" class="form-control">
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->name); ?>" <?php echo e($brand->name == $product->brand ?
                                        'selected':''); ?>>
                                        <?php echo e($brand->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Small Description (500 words)</label>
                                <textarea name="small_description" class="form-control"
                                    rows="4"><?php echo e($product->small_description); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea name="description" class="form-control"
                                    rows="4"><?php echo e($product->description); ?></textarea>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="seo-tab-pane" role="tabpanel" aria-labelledby="seo-tab"
                            tabindex="0">
                            <div class="my-3">
                                <label class="form-label"> Meta Title</label>
                                <input type="text" name="meta_title" value="<?php echo e($product->meta_title); ?>"
                                    class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta Description (500 words)</label>
                                <textarea name="meta_description" class="form-control"
                                    rows="4"><?php echo e($product->meta_description); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Meta keyword</label>
                                <textarea name="meta_keyword" class="form-control"
                                    rows="4"><?php echo e($product->meta_keyword); ?></textarea>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="details-tab-pane" role="tabpanel" aria-labelledby="details-tab"
                            tabindex="0">
                            <div class="row my-3">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Original Price</label>
                                        <input type="text" value="<?php echo e($product->original_price); ?>" name="original_price"
                                            class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Selling Price</label>
                                        <input type="text" value="<?php echo e($product->selling_price); ?>" name="selling_price"
                                            class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Quantity</label>
                                        <input type="number" value="<?php echo e($product->quantity); ?>" name="quantity"
                                            class="form-control" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input mx-0" <?php echo e($product->trending == '1' ? 'checked':''); ?> name="trending" type="checkbox" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">Trending </label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input mx-0" <?php echo e($product->featured == '1' ? 'checked':''); ?> name="featured" type="checkbox" id="flexCheckDefault">
                                        <label class="form-check-label" for="flexCheckDefault">Featured </label>
                                    </div>
                                </div>
                                <div class="col-md-4 ">
                                    <div class="form-check">
                                        <input class="form-check-input mx-0" <?php echo e($product->status == '1' ? 'checked':''); ?> name="status" type="checkbox" value=""
                                        id="flexCheckDefault2">
                                        <label class="form-check-label" for="flexCheckDefault2">
                                            Status
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="image-tab-pane" role="tabpanel" aria-labelledby="image-tab"
                            tabindex="0">
                            <div class="mb-3">
                                <label class="form-label">Product Images</label>
                                <input type="file" name="image[]" multiple class="form-control">
                            </div>
                            <div>
                                <?php if($product->productImages): ?>
                                <div class="row">
                                    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-2 m-2">
                                        <img src="<?php echo e(asset($image->image)); ?>" class="m-3 border"
                                            style="width:80px; height:80px;" alt="images">
                                        <a href="<?php echo e(url('admin/product-image/'.$image->id.'/delete')); ?>"
                                            class="m-3">Remove</a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php else: ?>
                                <h5>No images Added</h5>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="color-tab-pane" role="tabpanel" aria-labelledby="color-tab"
                            tabindex="0">
                            <div class="mb-3">
                                <label class="form-label m-2">Select color </label>
                                <hr class="mt-0">
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-md-3">
                                        <div class="p-2 border border-white">
                                            Color: <input type="checkbox" name="colors[<?php echo e($color->id); ?>]"
                                                value="<?php echo e($color->id); ?>" class="form-check-input m-2"
                                                value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?> <br>
                                            Quantity: <input type="number" name="color_quantity[<?php echo e($color->id); ?>]"
                                                style="width:70px; border:1px solid">
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="col-md-12">
                                        <h2>No color found</h2>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Color Name </th>
                                                <th>Quantity</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $product->productColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="prod-color-tr">
                                                <td>
                                                    <?php if($color_item->color): ?>
                                                    <?php echo e($color_item->color->name); ?></td>
                                                <?php else: ?>
                                                No Color Found
                                                <?php endif; ?>
                                                <td>
                                                    <div class="input-group mb-3" style="width:150px">
                                                        <input type="text" value="<?php echo e($color_item->quantity); ?>"
                                                            class="productColorQuantity form-control form-control-sm">
                                                        <button type="button" value="<?php echo e($color_item->color_id); ?>"
                                                            class="updateProductColorBtn btn btn-primary btn-sm text-white">Update</button>
                                                    </div>
                                                </td>

                                                <td>
                                                    <button type="button" value="<?php echo e($color_item->id); ?>"
                                                        class="deleteProductColorBtn btn btn-danger btn-sm">
                                                        Delete</button>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary mb-2">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
            $(document).ready( function(){
                $.ajaxSetup({
                    headers: {
                              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                });
        
           $(document).on('click', '.updateProductColorBtn', function(){
            
            var product_id = "<?php echo e($product->id); ?>"
            var prod_color_id = $(this).val();
            var quantity = $(this).closest('.prod-color-tr').find('.productColorQuantity').val();
            // alert(prod_color_id);

            if(quantity <=0){
                alert('Quantity is required');
                return false;
            }

            var data = {
                'product_id': product_id,
                'quantity': quantity
            };

            $.ajax({
                type: "POST",
                url: "/admin/product-color/"+prod_color_id,
                data: data,
                success: function(response){
                    alert(response.message)
                }
            });
        });

        $(document).on('click', '.deleteProductColorBtn', function(){
            
            var prod_color_id =  $(this).val();
            var thisClick = $(this);
            $.ajax({
                type: "GET",
                url: "/admin/product-color/"+prod_color_id+"/delete",
                success: function(response){
                    thisClick.closest('.prod-color-tr').remove();
                    alert(response.message);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>