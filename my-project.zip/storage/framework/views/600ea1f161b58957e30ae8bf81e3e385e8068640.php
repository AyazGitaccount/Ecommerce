<div class="row">
    <div class="col-md-12 grid-margin ">
        <div class="mx-4 my-4">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </div>
        <form wire:submit.prevent='store' class="mx-3 my-3">
            <?php echo csrf_field(); ?>
            <div class="card mb-3">
                <div class="card-header bg-primary">
                    <h3 class="text-white mb-0">Website</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Website Name</label>
                            <input type="text" wire:model.defer="website_name" value="<?php echo e($setting->website_name ?? ''); ?>" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Website URL</label>
                            <input type="text" wire:model.defer="webiste_url" value="<?php echo e($setting['webiste_url'] ?? ''); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Page Title</label>
                            <input type="text" wire:model.defer="page_title" value="<?php echo e($setting['page_title'] ?? ''); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Meta keywords</label>
                            <input type="text" wire:model.defer="meta_keyword" value="<?php echo e($setting['meta_keyword'] ?? ''); ?>" class="form-control">
                        </div> 
                        <div class="col-md-6 mb-3">
                            <label>Meta Description</label>
                            <input type="text" wire:model.defer="meta_description" value="<?php echo e($setting['meta_description'] ?? ''); ?>" class="form-control">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header bg-primary">
                    <h3 class="text-white mb-0">Website - Information</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label>Address</label>
                            <textarea  wire:model.defer="address" value="<?php echo e($setting['address'] ?? ''); ?>" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Phone 1 *</label>
                            <input type="text" wire:model.defer="phone1" value="<?php echo e($setting['phone1'] ?? ''); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Phone No.2</label>
                            <input type="text" wire:model.defer="phone2" value="<?php echo e($setting['phone2'] ?? ''); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Email 1 *</label>
                            <input type="text" wire:model.defer="email1" value="<?php echo e($setting['email1'] ?? ''); ?>" class="form-control">
                        </div> 
                        <div class="col-md-6 mb-3">
                            <label>Email 2</label>
                            <input type="text" wire:model.defer="email2" value ="<?php echo e($setting['email2']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header bg-primary">
                    <h3 class="text-white mb-0">Website - Social Media</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Facebook (Optional)</label>
                            <input type="text" wire:model.defer="facebook" value ="<?php echo e($setting['facebook']); ?>" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Twitter (Optional)</label>
                            <input type="text" wire:model.defer="twitter" value ="<?php echo e($setting['twitter']); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Instagram (Optional)</label>
                            <input type="text" wire:model.defer="instagram" value ="<?php echo e($setting['instagram']); ?>" class="form-control">
                        </div>
                         <div class="col-md-6 mb-3">
                            <label>Youtube (Optional)</label>
                            <input type="text" wire:model.defer="youtube"  value ="<?php echo e($setting['youtube']); ?>" class="form-control">
                        </div> 
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary text-white">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
   
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/admin/site-setting/site-setting.blade.php ENDPATH**/ ?>