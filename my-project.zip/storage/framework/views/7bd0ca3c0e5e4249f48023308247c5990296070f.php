<div class="py-3 py-md-4 ">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-8 text-center">
                <?php if(session('message')): ?>
                <h4 class="alert"><?php echo e(session('message')); ?></h4>
                <?php endif; ?>
                <div class="p-4 shadow bg-white">
                    <h3>Thank You for Shopping with Us </h3>
                    <a href="<?php echo e(url('collections')); ?>" class="btn btn-primary">Shop Now</a>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/thank-you-page.blade.php ENDPATH**/ ?>