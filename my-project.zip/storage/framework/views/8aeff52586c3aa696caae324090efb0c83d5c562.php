<div class="py-3 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="shadow bg-white p-3">
                    <h4 class="mb-4">My Orders</h4>
                    <hr>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th>Order ID</th>
                                <th>Tracking NO</th>
                                <th>Username</th>
                                <th>Payment Mode</th>
                                <th>Ordered Date</th>
                                <th>Status Message</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                               <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                   <tr>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->tracking_no); ?></td>
                                    <td><?php echo e($order->fullname); ?></td>
                                    <td><?php echo e($order->payment_mode); ?></td>
                                    <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                    <td><?php echo e($order->status_message); ?></td>
                                    <td><a href="<?php echo e(url('orders/'.$order->id)); ?>" class="btn btn-primary btn-sm ms-3">View</a></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                   <tr colspan="7">
                                    No Orders available
                                   </tr>
                               <?php endif; ?>
                                
                                
                            </tbody>
                        </table>
                        <div>
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/admin/orders/list-of-order.blade.php ENDPATH**/ ?>