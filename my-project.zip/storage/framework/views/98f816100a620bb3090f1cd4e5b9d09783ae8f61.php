<div class="d-inline">
<?php echo e($Cart_count); ?>

</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/cart-count.blade.php ENDPATH**/ ?>