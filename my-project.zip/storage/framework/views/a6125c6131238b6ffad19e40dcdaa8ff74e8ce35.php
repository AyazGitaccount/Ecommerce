<div>
    <?php echo $__env->make('livewire.admin.users.add-users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <ul class="alert alert-warning">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Users List
                            <a href="<?php echo e(url('admin/add-users')); ?>" class="btn btn-primary btn-sm float-end"  data-bs-toggle="modal" data-bs-target="#add-user-modal">Add User</a>
                        </h4>
                    </div>
                    <div class="card-boady m-3">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->role_as == '0'): ?>
                                         <label class="btn btn-primary btn-sm">User</label>
                                        <?php elseif($user->role_as == '1'): ?>
                                         <label class="btn btn-success btn-sm">Admin</label>
                                        <?php else: ?>
                                         <label class="btn btn-danger btn-sm">none</label>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a  wire:click='edit_user(<?php echo e($user->id); ?>)'  data-bs-toggle="modal" 
                                            data-bs-target="#Update_user"  class="btn btn-success me-2  btn-sm">
                                            Edit
                                        </a>
                                        <a  wire:click='delete_user(<?php echo e($user->id); ?>)' class="btn  btn-danger" 
                                            data-bs-toggle="modal" data-bs-target="#delete_user">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                 <tr>
                                    <td colspan="5">No users avilable</td>
                                 </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="mt-2">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/admin/users/users-page.blade.php ENDPATH**/ ?>