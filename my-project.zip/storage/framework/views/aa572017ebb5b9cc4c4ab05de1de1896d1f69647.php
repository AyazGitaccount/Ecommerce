
<?php $__env->startSection('title1','site settings'); ?>
<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.site-setting.site-setting', [])->html();
} elseif ($_instance->childHasBeenRendered('kQHuLxf')) {
    $componentId = $_instance->getRenderedChildComponentId('kQHuLxf');
    $componentTag = $_instance->getRenderedChildComponentTagName('kQHuLxf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kQHuLxf');
} else {
    $response = \Livewire\Livewire::mount('admin.site-setting.site-setting', []);
    $html = $response->html();
    $_instance->logRenderedChild('kQHuLxf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/site-setting/index.blade.php ENDPATH**/ ?>