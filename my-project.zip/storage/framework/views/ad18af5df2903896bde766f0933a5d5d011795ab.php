
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4>
                        Edit Slider
                        <a href="<?php echo e(url('admin/slider')); ?>" class="btn btn-primary btn-sm float-end">
                           Back </a>
                    </h4>
                </div>
            </div>
            <div class="card-body" style="background-color: white;">
                <form action="<?php echo e(url('admin/slider/'.$slider->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                      <label  class="form-label">Title</label>
                      <input type="text" class="form-control" value="<?php echo e($slider->title); ?>" name="title">
                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                      <label  class="form-label">Description</label>
                       <textarea  name="Description" id="" class="form-control" rows="3"><?php echo e($slider->description); ?></textarea>
                      <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label  class="form-label">Image</label>
                        <input type="file" class="form-control" name="image">
                        <img src="<?php echo e(asset("$slider->image")); ?>" alt="slider" style="width:50px; height:50px;">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-check-label mb-2" for="exampleCheck1">Status</label><br>
                      <input type="checkbox" name="status" class="form-check-input m-0" <?php echo e($slider->status =='1'? 'chekced':'unchecked'); ?> id="exampleCheck1"> Checked=hidden, uncheckd=visible
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                  </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>