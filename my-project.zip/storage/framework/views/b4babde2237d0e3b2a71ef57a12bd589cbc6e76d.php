

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.search.search-products', [])->html();
} elseif ($_instance->childHasBeenRendered('tToMZ4Q')) {
    $componentId = $_instance->getRenderedChildComponentId('tToMZ4Q');
    $componentTag = $_instance->getRenderedChildComponentTagName('tToMZ4Q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tToMZ4Q');
} else {
    $response = \Livewire\Livewire::mount('frontend.search.search-products', []);
    $html = $response->html();
    $_instance->logRenderedChild('tToMZ4Q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/frontend/search.blade.php ENDPATH**/ ?>