<div class="py-3 py-md-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="mb-4">Our Categories</h4>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-6 col-md-3">
                    <div class="category-card">
                    <a href="<?php echo e(url('/collections/'.$cat_item->slug)); ?>">
                        <div class="category-card-img">
                            <img src="<?php echo e(asset("$cat_item->image")); ?>" class="w-100" style="height:155px" alt="category_image">
                        </div>
                        <div class="category-card-body">
                            <h5><?php echo e($cat_item->name); ?></h5>
                        </div>
                    </a>
                </div>                
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               <div class="col-md-12">
                <h5>No Category Avilable</h5>
               </div>     
           <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/frontend/category-collection.blade.php ENDPATH**/ ?>