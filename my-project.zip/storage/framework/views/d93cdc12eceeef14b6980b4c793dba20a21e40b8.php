<div class="main-navbar shadow-sm sticky-top" id="navbar">
    <div class="top-navbar"  style="transition: top 0.3s;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-2 my-auto d-none d-sm-none d-md-block d-lg-block">
                    <h5 class="brand-name"><?php echo e($app_setting->website_name ?? 'website name'); ?></h5>
                </div>
                <div class="col-md-5 my-auto">
                    <form action="<?php echo e(url('/search')); ?>" method="GET" role="search">
                        <div class="input-group">
                            <input type="search"  name='search' value="" placeholder="Search your product" class="form-control" />
                            <button  class="btn bg-white"  type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-5 my-auto">
                    <ul class="nav justify-content-end">

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('cart')); ?>">
                                <i class="fa fa-shopping-cart"></i> Cart (<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.cart-count', [])->html();
} elseif ($_instance->childHasBeenRendered('piX6Czm')) {
    $componentId = $_instance->getRenderedChildComponentId('piX6Czm');
    $componentTag = $_instance->getRenderedChildComponentTagName('piX6Czm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('piX6Czm');
} else {
    $response = \Livewire\Livewire::mount('frontend.cart-count', []);
    $html = $response->html();
    $_instance->logRenderedChild('piX6Czm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('wishlist')); ?>">
                                <i class="fa fa-heart"></i> Wishlist (<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.wishlist-count', [])->html();
} elseif ($_instance->childHasBeenRendered('3ZMdVDm')) {
    $componentId = $_instance->getRenderedChildComponentId('3ZMdVDm');
    $componentTag = $_instance->getRenderedChildComponentTagName('3ZMdVDm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3ZMdVDm');
} else {
    $response = \Livewire\Livewire::mount('frontend.wishlist-count', []);
    $html = $response->html();
    $_instance->logRenderedChild('3ZMdVDm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>)
                            </a>
                        </li>

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                               <li class="nav-item">
                                   <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </i>
                            <?php endif; ?>
                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </i>
                            <?php endif; ?>
                            <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-user" style="margin-right: 3px"> </i><?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="<?php echo e(url('/profile')); ?>"><i class="fa fa-user"></i> Profile</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(url('/orders')); ?>"><i class="fa fa-list"></i> My Orders</a></li>
                                </li>
                                <li>
                                    
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                        <i class="fa fa-sign-out"><?php echo e(__('Logut')); ?></i>
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                    </form>

                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg" >
        <div class="container-fluid">
            <a class="navbar-brand d-block d-sm-block d-md-none d-lg-none" href="#">
                Funda Ecom
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/home')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/collections')); ?>">All Categories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/new_arrival')); ?>">New Arrivals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/featured-products')); ?>">Featured Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/collections/electronics')); ?>">Electronics</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </nav>
</div>


<?php $__env->startPush('scripts'); ?>
  <script>
    var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-100px";
  }
  prevScrollpos = currentScrollPos;
}
    </script>  
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/frontend/navebar.blade.php ENDPATH**/ ?>