<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <?php if(session('message')): ?>
                    <h5 class="alert alert-success mb-2"><?php echo e(session('message')); ?></h5>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="password-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card shadow">
                    <div class="card-header bg-primary">
                        <h4 class="mb-0 password-white">Change Password
                            <a href="<?php echo e(url('/profile')); ?>" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form wire:submit.prevent='changePassword'>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label>Current Password</label>
                                <input type="password" wire:model.defer="current_password" class="form-control" />
                                
                            </div>
                            <div class="mb-3">
                                <label>New Password</label>
                                <input type="password" wire:model.defer="new_password" class="form-control" />
                            </div>
                            <div class="mb-3">
                                <label>Confirm Password</label>
                                <input type="password" wire:model.defer="confirm_password" class="form-control" />
                            </div> 
                            <div class="mb-3 password-end">
                                <hr>
                                <button type="submit" class="btn btn-primary">Update Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp2\htdocs\Livewire_Ecommece_Project\resources\views/livewire/change-password/change-password.blade.php ENDPATH**/ ?>